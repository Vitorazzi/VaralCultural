<?php

namespace Source\Models;

use Source\Core\Connect;

class Category
{

    public function selectAll()
    {
        $stmt = Connect::getInstance()->query("SELECT * FROM categories");
        return $stmt->fetchAll();
    }

}