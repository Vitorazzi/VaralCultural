<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\User;
use Source\Models\Faq;
use Source\Models\Camisetas;
use Source\Models\Category;

class Web
{

    private $view;

    public function __construct()
    {
        $this->view = new Engine(__DIR__ . "/../../themes/web","php");
    }

    public function home()
    {
        echo $this->view->render("home",[]);
    }

    public function registro()
    {
        //$user = new User("Fernando","fernando@gmail.com","987654");
        //var_dump($user);
        //$user->insert();
       // $users = $user->selectAll();
        //var_dump($users);

        echo $this->view->render("registro",[
            //"users" => $user->selectAll()
        ]);
    }

    public function faq ()
    {
        $faqs = new Faq();
        //var_dump($faqs->selectAll());
        echo $this->view->render("faq",[
            "faqs" => $faqs->selectAll()
        ]);

    }

    public function camisetas(array $data) : void
    {
        //var_dump($data["categoryName"]);

       $camisetas = new Camisetas();

        if(!empty($data["categoryName"])){
            echo $this->view->render("camisetas",[
                "camisetas" => $camisetas->selectByCategory($data["categoryName"])
            ]);

            return;
        }

        echo $this->view->render("camisetas",["camisetas" => $camisetas->selectAll()]);
/*
            $camisetas->selectByCategory();
            echo $this->view->render("camisetas",[
                "camisetas" => $camisetas->selectByCategory($data["category"]),
                    "categories" => $this->camisetas]
            );
            return;

            echo $this->view->render("camisetas",[
                "categories" => $this->categories
            ]);
        }
*/
    }

    public function location()
    {
        $name = "Fábio Santos";
        echo $this->view->render("location",[
            "name" => "Fábio",
            "email" => "fabiosantos@ifsul.edu.br"
        ]);
    }

    public function quemsomos ()
    {
        echo $this->view->render("quemsomos");
    }

     public function login ()
    {
        echo $this->view->render("login");
    }

    public function estoque ()
    {
        echo $this->view->render("estoque");
    }

    public function adm ()
    {
        echo $this->view->render("adm");
    }



    
    public function error (array $data) : void
    {
        var_dump($data);
    }

}
