<?php
   $this->layout("_theme");
?>


<section class="hero">
        <h1>Camisetas do Varal Cutural</h1>    
    </section>

   
    <ul class="nav-links">
            <li><a href="<?= url('camisetas/herois'); ?>">Herois</a></li>
            <li><a href="<?= url('camisetas/filmes'); ?>">Filmes</a></li>
            <li><a href="<?= url('camisetas/animes'); ?>">Animes</a></li>
            <li><a href="<?= url('camisetas/series'); ?>">Series</a></li>
        </ul>

       


 <section class="products">
 <h2>Confira nossos Produtos</h2>
 <div class="product-container">

<?php
foreach ($camisetas as $camiseta) {
?>

<div class="product">
   <h3><?= $camiseta->nome?></h3>
   <img src="<?= url("assets/web/img/"); ?>camisa.png">
   <p>R$<?= $camiseta->preco?>,00</p>
   <p><?= $camiseta->tamanho?></p>
   <button>Comprar</button>
   </div>
<?php
}
?>
 </div>
 </section>