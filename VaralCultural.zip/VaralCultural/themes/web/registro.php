
<?php
   $this->layout("_theme");
?>
<html>
<head>
	<title>Registro</title>
	<link href="<?= url("/assets/web/css/login.css"); ?>" rel="stylesheet"/>


 
</head>
<body>
	<div class="container-registro">
		<h1>Registro</h1>
		<form class="php-email-form">
			<label for="nome">Nome:</label>
			<input type="text" id="nome" name="nome"><br>

			<label for="email">E-mail:</label>
			<input type="email" id="email" name="email"><br>

			<label for="senha">Senha:</label>
			<input type="password" id="senha" name="senha"><br>

			<input type="submit" value="Registrar">
		</form>
	</div>
</body>


<script type="text/javascript" async>
    const form = document.querySelector(".php-email-form");

    const headers = {
        email: "fabiosantos@ifsul.edu.br",
        password: "12345678"
    };

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        //console.log(new FormData(form));
        const data = await fetch(`<?= url("api/user");?>`,{
            method: "POST",
            body: new FormData(form),
            headers: headers
        });
        const user = await data.json();
        console.log(user);
    });
</script>
</html>
