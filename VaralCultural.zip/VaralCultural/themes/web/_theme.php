

<head>
    <meta charset="UTF-8">
    <title>Varal Cultural</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="<?= url("/assets/web/css/styles.css"); ?>" rel="stylesheet"/>
        <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/home.css">
    <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/adm.css">
    <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/estoque.css">
    <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/faq.css">
    <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/login.css">
    <link rel="stylesheet" href="<?= url(); ?>/assets/web/css/quemsomos.css">
</head>

<body>
<nav>
        <div class="logo">
            <a>Varal Cultural</a>
        </div>
        <ul class="nav-links">
            <li><a href="<?= url(''); ?>">Home</a></li>
            <li><a href="<?= url('quemsomos'); ?>">Quem Somos</a></li>
            <li><a href="<?= url('faq'); ?>">FAQ</a></li>

            <a href="<?= url('login'); ?>"> <button id="login">Login</button>  </a>
            <a href="<?= url('registro'); ?>"> <button id="registro">Registro</button> </a>
        </ul>
    </nav>

    <?= $this->section("content"); ?>



    <footer>
        <p>Varal Cultural &copy; 2023</p>
    </footer>
   