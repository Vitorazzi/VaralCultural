<?php
   $this->layout("_theme");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Consulta de Estoque</title>
    <link href="<?= url("/assets/web/css/estoque.css"); ?>" rel="stylesheet"/>

    
</head>
<body>

    
    <h1>Consulta de Estoque</h1>
    
    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Quantidade</th>
                <th>Preço</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Camiseta Preta</td>
                <td>25</td>
                <td>R$ 29,90</td>
            </tr>
            <tr>
                <td>Camiseta Branca</td>
                <td>18</td>
                <td>R$ 27,90</td>
            </tr>
            <tr>
                <td>Camiseta Vermelha</td>
                <td>10</td>
                <td>R$ 32,90</td>
            </tr>
            <tr>
                <td>Camiseta Azul</td>
                <td>5</td>
                <td>R$ 35,90</td>
            </tr>
        </tbody>
    </table>
</body>
</html>