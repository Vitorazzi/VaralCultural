
<?php
   $this->layout("_theme");
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quem Somos - Varal Cultural</title>
    <link href="<?= url("/assets/web/css/quem-somos.css"); ?>" rel="stylesheet"/>
</head>
<body>


    <div class="hero">
        <h1>QUEM SOMOS?</h1>
        <h3>Nossa missão:</h3>
        <p>Oferecer uma ampla variedade de opções, os usuários poderão encontrar facilmente camisetas de
            bandas, cantores, políticos, filmes e séries em um só lugar, evitando a necessidade de
            procurar em várias lojas diferentes.</p>
        <h3>Area de atuação:</h3>
        <p> Vemos geralmente
            camisetas dessa forma, em lojas físicas, o que limita o crescimento do comércio ao
            local em que está inserido, sem contar que são poucas as lojas voltadas apenas a isso.
            Porém no formato e-commerce, não haveria essa limitação, pois qualquer pessoa do país
            poderá acessar o site e comprar sua camiseta. O site terá parceria com lojas Stripme,
            Studiogeek, Brusinhas e Pitica</p> 
        <h3>Público alvo:</h3>
        <p>O Público Alvo do “Varal Cultural” são as pessoas que desejam ter uma camiseta de sua
            série, música, filme favorito. Porém em lojas físicas não conseguem encontrar de maneira
            tão fácil esse produtos. A idade média dos usuários seria bem variada, seria entre 10 a 70
            anos de idade.
            </p>
        </div>

       
</body>
</html>
