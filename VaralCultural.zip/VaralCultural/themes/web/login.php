<?php
   $this->layout("_theme");
?>
<html lang="en">


<link href="<?= url("/assets/web/css/login.css"); ?>" rel="stylesheet"/>
    <title>Formulário de Login</title>



    <div class="container-login">
        <h1>Login</h1>
        <form>
            <label for="username">Nome de Usuário:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Senha:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Login">
        </form>
    </div>

