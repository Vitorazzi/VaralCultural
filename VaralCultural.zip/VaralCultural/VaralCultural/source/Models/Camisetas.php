<?php

namespace Source\Models;

use Source\Core\Connect;

class Camisetas
{
    private $id;
    private $tamanho;
    private $nome;
    private $preco;

    public function selectAll()
    {
        $stm = Connect::getInstance()->query("SELECT * FROM camisetas");
        return $stm->fetchAll();

    }
public function selectByCategory(string $categoryName)
{
    $query = "SELECT camisetas.*
    FROM camisetas
    JOIN categories ON categories.id = camisetas.category_id
    WHERE categories.name LIKE '{$categoryName}'";
    
    $stmt = Connect::getInstance()->query($query);
    return $stmt->fetchAll();
}

}