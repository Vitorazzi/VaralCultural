<?php

const CONF_DB_HOST = "localhost";
const CONF_DB_USER = "root";
const CONF_DB_PASS = "";
// aqui deve ser alterado para o nome do banco de dados
const CONF_DB_NAME = "bd_varalcultural";

const CONF_URL_BASE = "http://127.0.0.1/VaralCultural"; // para produção
const CONF_URL_TEST = "http://127.0.0.1/VaralCultural"; //  para teste
