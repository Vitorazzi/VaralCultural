<?php

require __DIR__ . "/vendor/autoload.php";

use CoffeeCode\Router\Router;

ob_start();

$route = new Router(url(), ":");

$route->namespace("Source\App");

$route->group(null);

$route->get("/", "Web:home");
$route->get("/faq","Web:faq");
$route->get("/registro", "Web:registro");
$route->get("/quemsomos", "Web:quemsomos");
$route->get("/login", "Web:login");
$route->get("/location", "Web:location");
$route->get("/estoque", "Web:estoque");
$route->get("/adm", "Web:adm");
$route->get("/camisetas", "Web:camisetas");
$route->get("/camisetas/{categoryName}", "Web:camisetas");






$route->get("/ops/{errcode}", "Web:error");

$route->group("/app");
$route->get("/", "App:home");

$route->group(null);

$route->dispatch();

if ($route->error()) {
    $route->redirect("/ops/{$route->error()}");
}

ob_end_flush();
