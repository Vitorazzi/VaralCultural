<?php
   $this->layout("_theme");
?>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= url("/assets/web/css/adm.css"); ?>" rel="stylesheet"/>
    <title>Inserir Camisas</title>
</head>
<body>


    <h1>Inserir Camisas</h1>

    <form action="#" method="POST">
        <label for="produto">Produto:</label>
        <input type="text" id="produto" name="produto" placeholder="Informe o nome do produto" required><br>

        <label for="tamanho">Tamanho:</label>
        <select id="tamanho" name="tamanho" >
            <option value="pp">PP</option>
            <option value="p">P</option>
            <option value="m">M</option>
            <option value="g">G</option>
            <option value="gg">GG</option>
        </select><br>

        <label for="quantidade">Quantidade:</label>
        <input type="number" id="quantidade" name="quantidade"  placeholder="Digite a quantidade" min="1" required><br>

        <label for="preco">Preço:</label>
        <input type="number" id="preco" name="preco" min="0" placeholder="Digite o preço" step="0.01" required><br>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao"></textarea><br>

        <button type="submit">Inserir</button>
    </form>
</body>
</html>
