<?php
   $this->layout("_theme");
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Varal Cultural</title>
    <link href="<?= url("/assets/web/css/styles.css"); ?>" rel="stylesheet"/>

</head>

<body>


    <section class="hero">
        <h1>Bem-vindo ao Varal Cultural</h1>
        <p>Aqui você encontra as melhores camisas com estampas exclusivas!</p>
        <button href="<?= url('camisetas'); ?>">Compre Agora</button>
    </section>

    <section class="products">
        <h2>Confira nossos Produtos</h2>
        <div class="product-container">
            <div class="product">
            <img src="<?= url("assets/web/img/"); ?>camisa.png">
                <h3>Camisa 1</h3>
                <p>R$ 50,00</p>
                <button>Comprar</button>
            </div>
            
            <div class="product">
            <img src="<?= url("assets/web/img/"); ?>camisa.png">
                <h3>Camisa 2</h3>
                <p>R$ 60,00</p>
                <button>Comprar</button>
            </div>
            <div class="product">
            <img src="<?= url("assets/web/img/"); ?>camisa.png">
                <h3>Camisa 3</h3>
                <p>R$ 45,00</p>
                <button>Comprar</button>
            </div>
            <div class="product">
            <img src="<?= url("assets/web/img/"); ?>camisa.png">
                <h3>Camisa 4</h3>
                <p>R$ 55,00</p>
                <button>Comprar</button>
            </div>
        </div>
    </section>

    