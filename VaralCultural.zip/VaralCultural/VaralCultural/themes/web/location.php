<?php
   $this->layout("_theme");
?>
<?php
  echo "<h1>Olá, {$name}! Seu e-mail é {$email}</h1>";
?>
<link href="<?= url("/assets/web/css/location.css"); ?>" rel="stylesheet"/>