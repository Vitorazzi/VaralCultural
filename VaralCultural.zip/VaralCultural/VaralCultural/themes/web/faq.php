<?php
   $this->layout("_theme");
?>



<h1>Perguntas Mais Frequentes!</h1>

<?php
//var_dump($faqs);
if(!empty($faqs)){
    foreach ($faqs as $faq){
?>

<h2><p><?= $faq->question?></p></h2>
        <p><?= $faq->answer?></p></div>
   <?php }
}
?>